<?php

plantilla::home();
?>
<h3> Contacto</h3>
    <b>Correo:</b>
	<small>20131869@itla.edu.do </small>
	
	<b>Numero Telefono </b>
	<small>(829)842-0055</small>